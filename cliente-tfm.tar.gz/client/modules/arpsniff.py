import socket
from struct import *

def consultaARP(dest_ip,localMac,localIP):
  r = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3))
  r.bind(("eth0", 0))
  local_mac = [int(localMac[0:2],16),int(localMac[2:4],16),int(localMac[4:6],16),int(localMac[6:8],16),int(localMac[8:10],16),int(localMac[10:12],16)]
  local_ip=list(map(int,localIP.split('.')))
  ARP_FRAME = [
    pack('!6B', *(0xff,)*6), # dstmac
    pack('!6B', *local_mac), # sourcemac
    pack('!H', 0x0806), # eth type
    pack('!H', 0x0001), # HRD
    pack('!H', 0x0800), # PRO
    pack('!B', 0x06), # HLN
    pack('!B', 0x04), # PLN
    pack('!H', 0x0001), # OP
    pack('!6B', *local_mac), # SHA
    pack('!4B', *local_ip), # SPA
    pack('!6B', *(0x00,)*6), # THA
    pack('!4B', *dest_ip), # TPA
  ]
  chorizo=b''.join(ARP_FRAME)
  #print(chorizo.hex())
  r.send(b''.join(ARP_FRAME))
  r.close()

def procesaARP(packet):
  dataARP = {
    "origmac" : str(packet[6:12].hex()),
    "destmac" : str(packet[0:6].hex()),
    "hwsize" : str(packet[18:19].hex()),
    "protosize" : str(packet[19:20].hex()),
    "proto" : str(packet[16:18].hex()),
    "opcode" : str(packet[20:22].hex()),
    "srcmac" : str(packet[22:28].hex()),
    "srcip" : packet[28:32],
    "dstmac" : str(packet[32:38].hex()),
    "dstip" : packet[38:42]
  }
  return dataARP
