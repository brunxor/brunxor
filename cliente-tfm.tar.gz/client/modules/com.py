import requests,json

def peticionServer(token,funcion,data,serverurl): # data puede ser lista,dict,etc
  contenido=dict({'TOKEN' : token , funcion : data})
  contenidoJson=json.dumps(contenido)
  try:
    r = requests.post(serverurl,contenidoJson)
  except requests.exceptions.HTTPError as errh:
    print ("Http Error:",errh)
  except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
  except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
  except requests.exceptions.RequestException as err:
    print ("OOps: Something Else",err)
  #  print('Error en el request '+contenidoJson)
   
  try:
    print(f"Status Code: {r.status_code}, Response: {r.json()}")
    if r.status_code == 200:
      #print('200 - '+funcion+' - Datos enviados')
      recibido=r.json()
      result={}
      for funcionRes,contenido in recibido.items():
        if funcionRes == funcion:  #sólo recibirá la funcion que pide.
          result=contenido
      return(result)
      #respuestaServer(recibido)
    elif r.status_code == 401:
      peticionServer(0,'sendAgentData',token)
    else: 
      print('Error enviando datos')
  except:
    print('Error en en la respuesta ')
    

