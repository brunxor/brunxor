import sqlite3
from pathlib import Path

dbfile='DBclient.db'


def configFromDB():
  config=dict()
  for linea in dbSelect('config','*'):
    config[linea['dato']]=linea['valor']
  return config

def sql_connection():
  try:
    con = sqlite3.connect(dbfile)
    return con
  except:
    print('Error conectando a la base de datos')

def dict_factory(cursor, row):  # para leer de sqlite y crear diccionarios https://docs.python.org/3/library/sqlite3.html
  d = {}
  for idx, col in enumerate(cursor.description):
    d[col[0]] = row[idx]
  return d
  
def cleanDB():
  try:
    Path(dbfile).unlink()
  except OSError as err:
    print("Error eliminando fichero  - - OS error: {0}".format(err))

def init1st():
  if not Path(dbfile).is_file():
    creartables()
   
#dbSelect forma la consulta SELECT y devuelve un diccionario
# whe , True o False si queremos poner un WHERE
# order puede ser ASC o DESC
# LIMITE debe ser numerico
#
# 3 ejemplos:
#>>> database.dbSelect('tasks','*','columnaWHERE', '>=' ,'valorWHERE','DESC',1)
#SELECT * FROM tasks WHERE columnaWHERE = "valorWHERE" ORDER BY DESC LIMIT 1 ;
#>>> database.dbSelect('tasks','*')
#SELECT * FROM tasks ;
#>>> database.dbSelect('tasks','*',False,0,0,'DESC',1)
#SELECT * FROM tasks ORDER BY DESC LIMIT 1 ;

def dbSelect(tabla,columnas,wheColumnas='',wheCond=False,wheValores='',orderBy=False,order=False,lim=False):
  if type(columnas) is list:
    columnas=str(columnas).replace('[', '').replace(']','').replace("'","") 
  sql='SELECT '+columnas+' FROM '+tabla
  if wheCond:
    if type(wheColumnas) is list:
      wheColumnas=str(wheColumnas).replace('[', '(').replace(']',')')
    if type(wheValores) is list:
      wheValores=str(wheValores).replace('[', '(').replace(']',')')
    elif type(wheValores) is str:
      wheValores='"'+str(wheValores)+'"'
    sql=sql+' WHERE '+str(wheColumnas)+' '+wheCond+' '+str(wheValores)
  if order:
    sql=sql+' ORDER BY '+orderBy+' '+order
  if lim:
    sql=sql+' LIMIT '+str(lim)
  sql=sql+' ;'
  #print(sql)
  try:
    conexion=sql_connection()
    conexion.row_factory = dict_factory
    cur = conexion.cursor()
    cur.execute(sql)
    #conexion.close()
    return(cur.fetchall())
  except sqlite3.Error as er:
    print('Error en la consulta SQL: '+sql )
    print('SQLite error: %s' % (' '.join(er.args)))
    return(False)
    #print('SQLite traceback: ')
    #exc_type, exc_value, exc_tb = sys.exc_info()
    #print(traceback.format_exception(exc_type, exc_value, exc_tb))

#database.dbInsert('hostdiscovery',['mac','ip'],[1234,'192.168.204.56'],True)

def dbInsert(tabla,updColumnas,updValores,replace=False):
  sql='INSERT '
  if replace:
    sql=sql+' OR REPLACE'
  sql=sql+' INTO "'+tabla+'"'
  if type(updColumnas) is list:
    updColumnas=str(updColumnas).replace('[', '(').replace(']',')') 
    sql=sql+' '+str(updColumnas)+' VALUES '
  else:
    sql=sql+' ("'+str(updColumnas)+'") VALUES '
  if type(updValores) is list:
    updValores=str(updValores).replace('[', '(').replace(']',')')  
    sql=sql+' '+str(updValores)
  elif type(updValores) is str:
    sql=sql+' ("'+str(updValores)+'")'
  else:
    sql=sql+' ('+str(updValores)+')'
  sql=sql+' ;'
  #print(sql)
  try:
    conexion=sql_connection()
    conexion.row_factory = dict_factory
    cur = conexion.cursor()
    cur.execute(sql)
    conexion.commit()
    #conexion.close()
    return(True)
  except sqlite3.Error as er:
    print('Error en la consulta SQL: '+sql )
    print('SQLite error: %s' % (' '.join(er.args)))
    return(False)
  
def dbUpdate(tabla,updColumnas,updValores,wheColumnas='',wheCond=False,wheValores='',lim=False):
  sql='UPDATE '+tabla+' SET '
  if type(updColumnas) is list:
    updColumnas=str(updColumnas).replace('[', '(').replace(']',')') 
    sql=sql+' '+str(updColumnas)+' = '
  else:
    sql=sql+' ("'+str(updColumnas)+'") = '
  if type(updValores) is list:
    updValores=str(updValores).replace('[', '(').replace(']',')')  
    sql=sql+' '+str(updValores)
  elif type(updValores) is str:
    sql=sql+' ("'+str(updValores)+'")'
  else:
    sql=sql+' ('+str(updValores)+')'
  if wheCond:
    if type(wheColumnas) is list:
      wheColumnas=str(wheColumnas).replace('[', '(').replace(']',')')
    if type(wheValores) is list:
      wheValores=str(wheValores).replace('[', '(').replace(']',')')
    elif type(wheValores) is str:
      wheValores='"'+str(wheValores)+'"'
    sql=sql+' WHERE '+str(wheColumnas)+' '+wheCond+' '+str(wheValores)
  if lim:
    sql=sql+' LIMIT '+str(lim)
  sql=sql+' ;'
  #print(sql)
  try:
    conexion=sql_connection()
    conexion.row_factory = dict_factory
    cur = conexion.cursor()
    cur.execute(sql)
    conexion.commit()
    #conexion.close()
    return(True)
  except sqlite3.Error as er:
    print('Error en la consulta SQL: '+sql )
    print('SQLite error: %s' % (' '.join(er.args)))
    return(False)

def creartables():
  conexion=sql_connection()
  try:
    cur = conexion.cursor()
    cur.execute ('''
      CREATE TABLE IF NOT EXISTS "config" (
      "id"	INTEGER NOT NULL UNIQUE,
      "dato"	TEXT NOT NULL UNIQUE,
      "valor"	TEXT,
      PRIMARY KEY("id" AUTOINCREMENT));
    ''')
    cur.execute ('''
      CREATE TABLE IF NOT EXISTS "peticiones" (
      "id"	INTEGER NOT NULL UNIQUE,
      "funcion"	TEXT NOT NULL,
      "data"	TEXT,
      "completado"	INTEGER,
      PRIMARY KEY("id" AUTOINCREMENT));
    ''')
    cur.execute ('''
      CREATE TABLE IF NOT EXISTS "tasks" (
      "id"		INTEGER NOT NULL UNIQUE,
      "modulo"	TEXT,
      "argumentos"	TEXT,
      "ondiscovery"	TEXT,
      "dependon"	TEXT,
      "completado"	INTEGER,
      "prioridad"	INTEGER,
      "resultado"	BLOB,
      PRIMARY KEY("id"));
    ''')
    cur.execute ('''
      CREATE TABLE IF NOT EXISTS "hostdiscovery" (
      "mac"		TEXT NOT NULL UNIQUE,
      "ip"		TEXT,
      "lastts"	TEXT );
    ''')
    cur.execute ('''
      CREATE TABLE IF NOT EXISTS "netdiscovery" (
      "id"		INTEGER NOT NULL UNIQUE,
      "name"		TEXT,
      "niceName"		TEXT,
      "mac"		TEXT,
      "ip"		TEXT UNIQUE,
      "subnet"		INT,
      "inScope"		INT,
      PRIMARY KEY("id" AUTOINCREMENT));
    ''')
    cur.execute ('''

    ''')
    cur.execute('''
      INSERT OR REPLACE INTO "config" (dato,valor) 
      VALUES ('version','1') ;
    ''')
    conexion.commit()
  except:
    print('Error creartables')

#config=configFromDB()
