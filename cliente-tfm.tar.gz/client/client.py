import sys,getopt,socket,threading,requests,json,ifaddr,getmac
#from pathlib import Path
from modules import arpsniff,tasking,database
from time import sleep
from datetime import datetime

def main(argv):
  variables()
  global config
  global serverhost
  global objectiveInterface
  global localIP
  global localMac
  helpcommand='main.py ayuda'
  try:
    opts, args = getopt.getopt(argv,"hcas:p:",["help","clean","arpoff","server=","port"])
  except getopt.GetoptError:
    print(helpcommand)
  for opt, arg in opts:
    if opt in ("-h", "--help"):
      print(helpcommand)
      #sys.exit()
    if opt in ("-s", "--server="):
      serverhost['server']=arg
    if opt in ("-a", "--arpoff"):
      snifferOn=False
    if opt in ("-p", "--port="):
      serverhost['port']=arg
    elif opt in ("-c", "--clean"):
      database.cleanDB()
    #ejecutar funciones aquí
  database.init1st()
  config=database.configFromDB()
  defaultMac=adapters()
  agentid=peticionServer(0,'sendAgentData',defaultMac)
  updateConfig (agentid)
  sendNetworks(agentid)
  #estas 4 lineas indican el scope para el ARPsniff, limita a 1 IPv4
  netdiscovery=database.dbSelect('netdiscovery','*','inScope','=',1,False,False,1)
  objectiveInterface=netdiscovery[0]['name']
  localIP=netdiscovery[0]['ip']
  localMac=netdiscovery[0]['mac']
  serverurl='http://'+serverhost['server']+':'+serverhost['port']
  threading.Thread(target=consultaPeriodica, name="consultaPeriodica", args=(agentid,int(config['consultaSleepTime']),)).start()
  threading.Thread(target=tasking.auto, name="ejecutarTaskPendientes", args=(agentid,int(config['taskSleepTime']),serverurl,)).start()
  if snifferOn:
    threading.Thread(target=sniffer, name="SnifferPackets",args=(agentid,)).start()

def variables():
  global serverhost
  global objectiveInterface
  global localIP
  global localMac
  global hostdiscovery
  global listaip
  global listaipconsulta
  objectiveInterface=''
  localIP=''
  localMac=''
  hostdiscovery=dict()
  serverhost=dict()
  listaip=[]
  listaipconsulta=[]

def consultaPeriodica(agentid,tiempo):
  while True:
    updateConfig (agentid)
    updateTasks (agentid)
    sleep(tiempo)

def updateConfig (agentid):
  global config
  res=peticionServer(agentid,'getConfig',config['version'])
  if res != 0:
    try:
      for linea in res:
        database.dbInsert('config',['dato','valor'],[str(linea['dato']),str(linea['valor'])],True)
    except:
      print('Error')
    config=database.configFromDB()

def sendNetworks(agentid):  
  netdiscovery=database.dbSelect('netdiscovery','*')
  peticionServer(agentid,'sincNets',netdiscovery)

def adapters():
  for adapter in ifaddr.get_adapters():
    inScope=0
    if adapter.name != "lo":
      inScope=1
    mac=getmac.get_mac_address(adapter.name)
    for ip in adapter.ips:
      if ip.network_prefix > 32:
        inScope=0
      else:
        defaultMac=mac.replace(':', '')
      database.dbInsert('netdiscovery',['name','niceName','mac','ip','subnet','inScope'],[adapter.name,adapter.nice_name,mac.replace(':', ''),str(ip.ip),ip.network_prefix,inScope])
  return defaultMac

def updateTasks (agentid):
  res=peticionServer(agentid,'getTasks','0')
  try:
    for linea in res:
      if str(linea['agentid'])==agentid:
        database.dbInsert('tasks',['id','modulo','argumentos','completado','prioridad'],[str(linea['id']),str(linea['modulo']),str(linea['argumentos']),0,str(linea['prioridad'])],True)
  except:
    print('Error')

def sniffer(agentid):
  try:
    s = socket.socket( socket.AF_PACKET , socket.SOCK_RAW , socket.ntohs(0x0003))
    sendHosts(agentid)
    actualizalistasip()
    while True:
      packet=s.recvfrom(65565)
      packet = packet[0]
      ethtype = str(packet[12:14].hex()) # IPv4:800 IPv6:86dd ARP:0806
      if ethtype == '0806':
        dataARP=arpsniff.procesaARP(packet)
        insertapares(agentid,dataARP["srcmac"],dataARP["srcip"])
        insertapares(agentid,dataARP["dstmac"],dataARP["dstip"])
  except Exception as e:
    print(e)

def insertarhostsql(mac,ip):
    lastts= int(datetime.timestamp(datetime.now()))
    if str(mac) != "000000000000" and str(mac) != "ffffffffffff" and str(socket.inet_ntoa(ip)) != "0.0.0.0":
      database.dbInsert('hostdiscovery',['mac','ip','lastts'],[str(mac),str(socket.inet_ntoa(ip)),str(lastts)],True)

def sendHosts(agentid):  ## eliminar????
  #global config
  global hostdiscovery
  hostdiscovery=database.dbSelect('hostdiscovery','*')
  peticionServer(agentid,'sincHost',hostdiscovery)
		
def insertapares(agentid,mac,ip):
  global listaipconsulta
  actualizalistasip()
  if str(socket.inet_ntoa(ip)) not in listaip:
    if str(mac) != "000000000000" and str(mac) != "ffffffffffff" and str(socket.inet_ntoa(ip)) != "0.0.0.0":
      insertarhostsql(mac,ip)
      #sendHostToServer(mac,ip)
      sendHosts(agentid)
      print(mac+' - '+str(socket.inet_ntoa(ip)))
      listaip.append(socket.inet_ntoa(ip))
    else :
      if socket.inet_ntoa(ip) not in listaipconsulta:
        listaipconsulta.append(socket.inet_ntoa(ip))
        consulta_thread= threading.Thread(target=controlPeticionesARP, name="consulta",args=(ip,2,)).start()
   
def actualizalistasip():
  global config
  global hostdiscovery
  global listaip
  antiguedad=int(datetime.timestamp(datetime.now())) - int(config['maxoldarp'])
  for linea in hostdiscovery:
    if linea['ip'] in listaip:
      if int(linea['lastts']) < antiguedad :
        listaip.remove(linea['ip'])
        #print ("ARP viejo "+linea['ip'])
        listaipconsulta.append(linea['ip'])
        consulta_thread= threading.Thread(target=controlPeticionesARP, name="consulta",args=(socket.inet_aton(linea['ip']),1,))
        consulta_thread.start()
    else:
      if int(linea['lastts']) >= antiguedad :
        listaip.append(linea['ip'])
        #print ("IP conocida "+linea['ip'])

def controlPeticionesARP(ip,volumen):
  global config
  for i in range(volumen):
    if str(socket.inet_ntoa(ip)) in listaip:
      continue
    else:
      #print('Ralizamos peticion ARP para:'+socket.inet_ntoa(ip))
      arpsniff.consultaARP(ip,localMac,localIP)
    sleep(int(config['arpReqSleepTime']))
  try:
    listaipconsulta.remove(socket.inet_ntoa(ip))
  except:
    pass

def peticionServer(token,funcion,data): # data puede ser lista,dict,etc
  global serverhost
  url='http://'+serverhost['server']+':'+serverhost['port']
  #print(url)
  contenido=dict({'TOKEN' : token , funcion : data})
  contenidoJson=json.dumps(contenido)
  #print(str(token)+funcion+str(data))
  try:
    r = requests.post(url,contenidoJson)
    print(f"Status Code: {r.status_code}, Response: {r.json()}")
    if r.status_code == 200:
      recibido=r.json()
      result={}
      for funcionRes,contenido in recibido.items():
        if funcionRes == funcion:  #sólo recibirá la funcion que pide.
          result=contenido
      return(result)
    elif r.status_code == 401: #Recupera el token
      agentid=peticionServer(0,'sendAgentData',token)
      updateConfig (agentid)
    else: 
      print('Error enviando datos')
  except:
    print('Error en consulta '+funcion)

if __name__ == "__main__":
#  try:
    main(sys.argv[1:])
#  except:
#    print('No se reconoce el comando')
